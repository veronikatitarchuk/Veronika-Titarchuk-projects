#include <iostream>
using namespace std;
#include "Header.h"

int main(void)
{
	cout << "start" << endl;
	try
	{
		Date::showDefault();
		cout << endl;
		Date::setDefault(1, Date::Month(1), 1970);
		Date::showDefault();
		cout << endl;
		Date::setDefault();
		Date d;
		Date d1(14, 10, 1991);
		Date d2(25, Date::Month(7), 1991);
		Date d3(d1);

		cout << "test ++ -- ========================================================" << endl;

		cout << "++(" << d1 << ')' << endl;
		++d1;
		cout << d1 << endl;
		cout << "(" << d1 << ")++" << endl;
		d1++;
		cout << d1 << endl;

		cout << "--(" << d2 << ')' << endl;
		--d2;
		cout << d2 << endl;
		cout << "(" << d2 << ")--" << endl;
		d2--;
		cout << d2 << endl;

		cout << "test ++ -- edge cases Feb ==========================================" << endl;
		Date dLeap(28, 02, 2000);
		cout << "++(" << dLeap << ')' << endl;
		++dLeap;
		cout << dLeap << endl;
		cout << "++(" << dLeap << ')' << endl;
		++dLeap;
		cout << dLeap << endl;
		cout << "====================================================================" << endl;
		Date dLeap2(01, 03, 1900);
		cout << '(' << dLeap2 << ")--" << endl;
		dLeap2--;
		cout << dLeap2 << endl;
		cout << "====================================================================" << endl;
		Date dLeap3(01, 03, 2003);
		cout << "--(" << dLeap3 << ')' << endl;
		--dLeap3;
		cout << dLeap3 << endl;
		cout << "test 30-31 days" << endl;
		cout << "=====new year=======================================================" << endl;
		Date dec31(31, 12, 2000);
		cout << "++(" << dec31 << ')' << endl;
		++dec31;
		cout << dec31 << endl;
		cout << "--(" << dec31 << ')' << endl;
		--dec31;
		cout << dec31 << endl;
		cout << "====================================================================" << endl;
		Date may1(01, 05, 2000);
		cout << "--(" << may1 << ')' << endl;
		--may1;
		cout << may1 << endl;
		cout << "test wrong date" << endl;
		Date x(48, 14, 2008);
	}
	catch (const Date::BadDate& bd)
	{
		cerr << "Bad date: " << bd << endl;
	}
	cout << "end" << endl;
	return 0;
}