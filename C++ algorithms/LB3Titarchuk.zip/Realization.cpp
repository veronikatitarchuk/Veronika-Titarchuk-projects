#include "Header.h"
#include <time.h>

string Date::monthNames[12] =
{
	"Jan", "Feb", "Mar", "Apr", "May", "Jun",
	"Jul", "Aug", "Sep", "Oct", "Nov", "Dec"
};

bool Date::defaultSet = false;
Date Date::defaultDate = Date();

bool Date::leapYear(const int y)
{
	return !(y % 4) && ((y % 100) || !(y % 400));
}

Date::Date(const int d, const Month m, const int y)
{
	fillDate(d, m, y);
}

Date::Date(const int d, const int m, const int y)
{
	fillDate(d, Month(m), y);
}

Date::Date(const Date& d)
{
	fillDate(d.day(), d.month(), d.year());
}

void Date::fillDate(const int d, const Month m, const int y)
{
	if (!defaultSet)
		setDefault();
	_day = d ? d : defaultDate._day;
	_month = m ? m : defaultDate._month;
	_year = y ? y : defaultDate._year;
	validateDate(_day, _month, _year);
#ifndef NDEBUG
	cout << "Data constructor: " << *this << endl;
#endif // !NDEBUG
	return;
}

Date::~Date() {}

const string Date::getMonthName() const
{
	return monthNames[month() - 1];
}

void Date::setDefault(const int d, const Month m, const int y)
{
	defaultDate = Date(d, m, y);
	defaultSet = true;
	return;
}

void Date::setDefault()
{
	struct tm* today = new tm;
	time_t timer;
	time(&timer);
	gmtime_s(today, &timer);
	defaultDate._day = today->tm_mday;
	defaultDate._month = ++(today->tm_mon);
	defaultDate._year = today->tm_year += 1900;
	defaultSet = true;
	return;
}

void Date::showDefault()
{
	cout << defaultDate;
	return;
}

int Date::getMonthDays(const Month month, const int year)
{
	int numberOfDays = 0;
	switch (month)
	{
	case feb: numberOfDays = 28 + leapYear(year); break;
	case apr: case jun: case sep: case nov: numberOfDays = 30; break;
	case jan: case mar: case may: case jul: case aug: case oct: case dec: numberOfDays = 31; break;
	}
	return numberOfDays;
}

void Date::normalizeDate()
{
	int numberOfDays = getMonthDays(month(), year());
	if (_day > numberOfDays)
	{
		_day = 1;
		++_month;
	}
	if (_day < 1)
	{
		--_month;
	}
	if (_month < 1)
	{
		_month = 12;
		--_year;
	}
	if (_month > 12)
	{
		_month = 1;
		++_year;
	}
	if (!_day)
		_day = getMonthDays(month(), year());
	return;
}

const Date& Date::operator++()
{
	++_day;
	normalizeDate();
	return *this;
}

const Date  Date::operator++(int)
{
	Date res = *this;
	++* this;
	return res;
}

const Date& Date::operator--()
{
	--_day;
	normalizeDate();
	return *this;
}

const Date  Date::operator--(int)
{
	Date res = *this;
	--* this;
	return res;
}

void Date::validateDate(const int day, const int month, const int year)
{
	int numberOfDays = getMonthDays(Month(month), year);
	if (day < 1 || numberOfDays < day || year < 1)
		throw BadDate(day, month, year);
}

void Date::setDay(int day)
{
	validateDate(day, month(), year());
	_day = day;
}

void Date::setMonth(int month)
{
	validateDate(day(), month, year());
	_month = month;
}

void Date::setDYear(int year)
{
	validateDate(day(), month(), year);
	_year = year;
}

ostream& operator<<(ostream& os, const Date& d)
{
	os << d.day() << ' ' << d.getMonthName() << ' ' << d.year();
	return os;
}

ostream& operator<<(ostream& os, const Date::BadDate& bd)
{
	os << bd._day << ':' << bd._month << ':' << bd._year;
	return os;
}