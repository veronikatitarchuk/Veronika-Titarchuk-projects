#include "segment.h"

int main() {

	Segment sg1(-3, -3, 4, 4);
	Segment sg2(4, 5, 8, 9);

	Point p1(5, 6); //right to sg1
	Point p2(-2, 0); //between points of sg1
	Point p3(-5, -5); //left to sg1
	Point p4(-4, -7); //left to sg1
	Point p5(-2, -2); //On the segment

	cout << "Amount of segments: " << sg2.amount() << endl;
	cout << "Length of the first segment: " << sg1.length() << endl;
	cout << "ID of the first segment: " << sg1.getID() << endl;
	cout << "Distance from point p1 to sg1: " << sg1.distance(p1) << endl;
	cout << "Distance from point p2 to sg1: " << sg1.distance(p2) << endl;
	cout << "Distance from point p3 to sg1: " << sg1.distance(p3) << endl;
	cout << "Distance from point p4 to sg1: " << sg1.distance(p4) << endl;
	cout << "Distance from point p5 to sg1: " << sg1.distance(p5) << endl;


	Segment sg3(p2, p5);
	cout << "sg3: " << sg3 << endl;
	cout << "sg3 start point: " << sg3.start() << endl;
	cout << "sg3 end point: " << sg3.end() << endl;
	cout << "sg3 start X: " << sg3.startX() << endl;
	cout << "sg3 start Y: " << sg3.startY() << endl;
	cout << "sg3 end X: " << sg3.endX() << endl;
	cout << "sg3 end Y: " << sg3.endY() << endl;
	cout << "Amount of segments: " << sg3.amount() << endl;

	sg3.~Segment();


	return 0;
}