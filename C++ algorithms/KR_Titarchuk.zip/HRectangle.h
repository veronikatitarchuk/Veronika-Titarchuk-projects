#pragma once
#include "HTetragon.h"

class HRectangle : public HTetragon
{
private:
	Point _a;
	size_t _lenX;
	size_t _lenY;
public:
	HRectangle();
	HRectangle(const Point&, const size_t, const size_t);
	~HRectangle() {};
	HRectangle(const HRectangle&);
	HRectangle& operator=(const HRectangle&);

	inline size_t lenX() const { return _lenX; }
	inline size_t lenY() const { return _lenY; }

	inline double perimeter() const { return (_lenX + _lenY) * 2; }
	inline double area() const { return _lenX * _lenY; }

	const Point apexA() const { return _a; }
	const Point apexB() const;
	const Point apexC() const;
	const Point apexD() const;

	void setA(const Point&);
	void setB(const Point&);
	void setC(const Point&);
	void setD(const Point&);

	const Segment side_AB() const;
	const Segment side_BC() const;
	const Segment side_CD() const;
	const Segment side_DA() const;
};

HRectangle operator+(const HTetragon&, const HTetragon&);