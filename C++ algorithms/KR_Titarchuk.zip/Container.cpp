#include "Container.h"

HRectangle& Container::operator[] (size_t index)
{
	if (index >= _size)
		throw BadContainer("index out of bound: ", index);
	return _data[index];
};

const HRectangle& Container::operator[] (size_t index) const
{
	if (index >= _size)
		throw BadContainer("index out of bound: ", index);
	return _data[index];
};


void Container::resize(const size_t newSize) {
	HRectangle* newData = new HRectangle[newSize];
	for (size_t i = 0; i < _size; ++i)
		newData[i] = _data[i];

	delete[] _data;
	_data = newData;
	_capacity = newSize;
}


void Container::removeAt(const size_t index) {
	if (index >= _size)
		throw BadContainer("Index out of bound", index);
	_size--;
	for (int i = index; i < _size; ++i)
		_data[i] = _data[i + 1];

	if (_size < _capacity / 3)
		resize(_size * 1.5);
}


void Container::addElement(const HRectangle& a) {
	if (_size >= _capacity)
		resize(_capacity * 2);

	_data[_size++] = a;
}

HRectangle Container::getUnion() const {
	if (empty())
		return HRectangle(Point(0, 0), 0, 0);

	size_t leftX = _data[0].apexA().x();
	size_t bottomY = _data[0].apexA().y();
	size_t rightX = _data[0].apexC().x();
	size_t topY = _data[0].apexC().y();

	for (int i = 1; i < _size; ++i) {
		leftX = leftX < _data[i].apexA().x() ? leftX : _data[i].apexA().x();
		bottomY = bottomY < _data[i].apexA().y() ? bottomY : _data[i].apexA().y();
		rightX = rightX > _data[i].apexC().x() ? rightX : _data[i].apexC().x();
		topY = topY > _data[i].apexC().y() ? topY : _data[i].apexC().y();
	}

#ifndef NDEBUG
	HRectangle res(Point(leftX, bottomY), rightX - leftX, topY - bottomY);
	for (int i = 0; i < _size; ++i)
		assert(_data[i] < res);
	return res;
#else
	return HRectangle(Point(leftX, bottomY), rightX - leftX, topY - bottomY);
#endif // !NDEBUG

}


Container::Container(const Container& c) : _capacity(c._capacity), _size(c._size), _data(new HRectangle[_size])
{
	for (int i = 0; i < _size; ++i)
		_data[i] = c._data[i];
}

const Container& Container::operator=(const Container& c)
{
	_capacity = c._capacity;
	_size = c._size;
	delete[] _data;
	_data = new HRectangle[_size];
	for (int i = 0; i < _size; ++i)
		_data[i] = c._data[i];
	return *this;
}

Container::Container(Container&& c) : _capacity(c._capacity), _size(c._size), _data(c._data)
{
	c._size = 0;
	c._capacity = 0;
	c._data = nullptr;
}

const Container& Container::operator=(Container&& c)
{
	_capacity = c._capacity;
	_size = c._size;
	delete[] _data;
	_data = c._data;

	c._size = 0;
	c._capacity = 0;
	c._data = nullptr;
	return *this;
}

Container Container::lessThan(const HRectangle& hr) const
{
	Container res(_size);

	for (int i = 0; i < _size; ++i)
		if (_data[i] < hr)
			res.addElement(_data[i]);

	return res;
}


std::ostream& operator<<(std::ostream& os, const Container& t) 
{
	for (int i = 0; i < t.size(); ++i)
		os << i << ':' << t[i] << endl;
	return os;
}