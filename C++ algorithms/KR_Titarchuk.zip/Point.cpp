#include "point.h"

int Point::_freeID = 0;

Point::Point(double x, double y) : _x(x), _y(y), _pointID(++_freeID)
{
#ifndef NDEBUG
	cout << "Point " << _pointID << " created." << endl;
#endif // !NDEBUG

	return;
}

Point::Point(const Point& a) : _x(a._x), _y(a._y), _pointID(++_freeID)
{
#ifndef NDEBUG
	cout << "Point " << _pointID << " copied." << endl;
#endif // !NDEBUG

	return;
}

Point::~Point()
{
#ifndef NDEBUG
	cout << "Point removed." << endl;
#endif // !1

	return;
}


Point& Point :: operator=(const Point& a)
{
	_x = a._x;
	_y = a._y;

	return *this;
}

ostream& operator<<(ostream& ostr, const Point& a)
{
	ostr << "(" << a.x() << ";" << a.y() << ")";
	return ostr;
}

const Point operator+ (const Point& u, const Point& v)
{
	return Point(u.x() + v.x(), u.y() + v.y());
}

Point& operator+=(Point& a, const Point& b)
{
	a.x() += b.x();
	a.y() += b.y();
	return a;
}

bool operator==(const Point& u, const Point& v)
{
	if ((u.x() == v.x()) && (u.y() == v.y()))
		return true;
	return false;
}

bool operator!=(const Point& u, const Point& v)
{
	return !(u == v);
}

double Point::distanceTo(const Point& p) const
{
	return sqrt((_x - p._x) * (_x - p._x) + (_y - p._y) * (_y - p._y));
}
