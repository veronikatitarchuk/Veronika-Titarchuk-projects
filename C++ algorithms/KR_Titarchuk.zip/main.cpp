#include "HRectangle.h"
#include "HSquare.h"
#include "Container.h"

int main() {

	Point a1 = Point(1, 3);
	HTetragon* ht1 = new HRectangle(a1, 10, 13);
	cout << *ht1;

	HSquare hsq1(Point(2, 1), 4);
	HSquare hsq2(hsq1);
	HSquare hsq3(Point(3, 2), 7);
	HRectangle hr4(Point(5, 5), 6, 8);
	HSquare hsq5(Point(7, 6), 6);
	HSquare hsq6(Point(3, 27), 4);
	HRectangle hr7(Point(6, 3), 5, 10);
	HSquare hsq8(Point(7, 7), 67);
	hsq2 = hsq1;

	cout << "Get apexA of square: " << hsq3.apexA() << endl;
	cout << "Get apexB of rectangle: " << hr7.apexB() << endl;
	cout << "Get area of rectangle: " << hr4.area() << endl;
	cout << "Get area of square: " << hsq6.area() << endl;

	cout << "less: " << (*ht1 < hsq1) << endl;

	cout << "\n\nUnion\n" << *ht1 + hsq1 << endl;

	Container cn(10);
	cn.addElement(hsq1);
	cn.addElement(hsq2);
	cn.addElement(hsq3);
	cn.addElement(hr4);
	cn.addElement(hsq5);
	cn.addElement(hsq6);
	cn.addElement(hr7);
	cn.addElement(hsq8);
	cn.removeAt(1);

	cout <<"Container: \n" << cn << endl;

	cout << cn[0] << "inside container" << endl;

	try 
	{
		cout << cn[1] << "inside container" << endl;
	}
	catch (const Container::BadContainer& bc) 
	{
		bc.diagnose();
	}

	cout << "UNION" << cn.getUnion() << endl;


	Container cn2;
	cn2.addElement(hsq3);
	cn2 = std::move(cn);

	Container c(std::move(cn2));

	Container less = cn2.lessThan(hsq1);
	cout << "CONTAINERLESS" << less << endl;

	return 0;
}