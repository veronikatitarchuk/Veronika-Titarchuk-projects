#pragma once
#include "HRectangle.h"
#include <iostream>
using namespace std;

class Container
{
private:
	size_t _capacity;
	size_t _size;
	HRectangle* _data;
	void resize(const size_t newSize);

	
public:
	class BadContainer;
	Container(const Container&);
	const Container& operator=(const Container&);

	Container(Container&&);
	const Container& operator=(Container&&);

	explicit Container() : _capacity(10), _size(0), _data(new HRectangle[10]) {}
	explicit Container(const size_t size) : _capacity(size), _size(0), _data(new HRectangle[size]) {}
	~Container() { delete[] _data; }

	inline size_t capacity() const { return _capacity; }
	inline size_t size() const { return _size; }

	void removeAt(const size_t index);
	void addElement(const HRectangle&);
	inline bool empty() const { return _size == 0; }
	HRectangle& operator[] (size_t index);
	const HRectangle& operator[] (size_t index) const;

	HRectangle getUnion() const;
	Container lessThan(const HRectangle&) const;
};


class Container::BadContainer
{
public:
	BadContainer(const string& s = "unknown", const int index = 0) :
		_trouble(s), _index(index) {};
	~BadContainer() {}
	void diagnose() const
	{
		cout << "Bad Container: " << _trouble;
		if (_index)
			cout << ": " << _index << endl;
	}

private:
	string _trouble;
	int _index;
};

std::ostream& operator<<(std::ostream& os, const Container& t);