#pragma once
#include "HRectangle.h"

class HSquare : public HRectangle
{
private:
	HRectangle::lenX;
	HRectangle::lenY;

public:
	HSquare();
	HSquare(const Point&, const size_t);
	~HSquare() {};
	HSquare(const HSquare&);
	HSquare& operator=(const HSquare&);


	inline size_t len() const { return HRectangle::lenX(); }

	inline double perimeter() const { return HRectangle::perimeter(); }
	inline double area() const { return HRectangle::area(); }

	const Point apexA() const { return HRectangle::apexA(); }
	const Point apexB() const { return HRectangle::apexB(); }
	const Point apexC() const { return HRectangle::apexC(); }
	const Point apexD() const { return HRectangle::apexD(); }

	void setA(const Point& x) { return HRectangle::setA(x); }
	void setB(const Point& x) { return HRectangle::setB(x); }
	void setC(const Point& x) { return HRectangle::setC(x); }
	void setD(const Point& x) { return HRectangle::setD(x); }

	const Segment side_AB() const { return HRectangle::side_AB(); }
	const Segment side_BC() const { return HRectangle::side_BC(); }
	const Segment side_CD() const { return HRectangle::side_CD(); }
	const Segment side_DA() const { return HRectangle::side_DA(); }
};