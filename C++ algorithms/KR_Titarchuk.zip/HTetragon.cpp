#include "HTetragon.h"
#include <cassert>

HTetragon::~HTetragon() {}

HTetragon::HTetragon() {}

std::ostream& operator<<(std::ostream& os, const HTetragon& ht)
{
    os << "Apexes:\n    A: " << ht.apexA() << "\n    B: " << ht.apexB() << "\n    C: " << ht.apexC() << "\n    D: " << ht.apexD() << endl
        << "Sides:\n    AB: " << ht.side_AB() << "\n    BC: " << ht.side_BC() << "\n    CD: " << ht.side_CD() << "\n    DA: " << ht.side_DA() << endl
        << "Perimeter: " << ht.perimeter() << endl << "Area: " << ht.area() << endl;
    return os;
}

bool operator<(const HTetragon& c, const HTetragon& b) 
{
    return c.side_AB().length() < b.side_AB().length() && c.side_BC().length() < b.side_BC().length();
}

