#include "segment.h"

int Segment::_freeID = 0;

Segment::Segment(const double x1, const double y1, const double x2, const double y2) : _a(x1, y1), _b(x2, y2), _myId(++_freeID)
{
#ifndef NDEBUG
	cout << "Segment " << _myId << " created." << endl;
#endif // !NDEBUG
	return;
}

Segment::Segment(const Point& start, const Point& end) : _a(start), _b(end), _myId(++_freeID)
{
#ifndef NDEBUG
	cout << "Segment " << _myId << " created." << endl;
#endif // !NDEBUG
	return;
}

Segment::Segment(const Segment& s) : _a(s._a), _b(s._b), _myId(++_freeID)
{
#ifndef NDEBUG
	cout << "Segment " << _myId << " coppied." << endl;
#endif // !NDEBUG
	return;
}

Segment::~Segment()
{
#ifndef NDEBUG
	cout << "Segment removed." << endl;
#endif // !1

	return;
}

Segment& Segment:: operator=(const Segment& s)
{
	_a = s._a;
	_b = s._b;

	return *this;
}

double Segment::length() const
{
	return sqrt((_a.x() - _b.x()) * (_a.x() - _b.x()) + (_a.y() - _b.y()) * (_a.y() - _b.y()));
}


//!!!!!!! WHEN POINT ON THE SEGMENT !!!!!!!!!
double Segment::distance(const Point& p) const
{
	double pa = p.distanceTo(_a);
	double pb = p.distanceTo(_b);
	double ab = _a.distanceTo(_b);

	if (pb * pb > pa * pa + ab * ab)
	{
		return pa;
	}

	if (pa * pa > ab * ab + pb * pb)
	{
		return pb;
	}

	double deltX = _b.x() - _a.x();
	double deltY = _b.y() - _a.y();
	double absRes = abs(deltY * p.x() - deltX * p.y() + _b.x() * _a.y() - _a.x() * _b.y());
	double sqrtRes = sqrt(deltX * deltX + deltY * deltY);

	return absRes / sqrtRes;
}

ostream& operator<<(ostream& ostr, const Segment& s)
{
	ostr << '[' << s.start() << ';' << s.end() << ']';
	return ostr;
}