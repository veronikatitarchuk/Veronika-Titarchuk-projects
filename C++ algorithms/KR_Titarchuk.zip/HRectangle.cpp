#include "HRectangle.h"

HRectangle::HRectangle() :_a(0, 0), _lenX(1), _lenY(1) {}

HRectangle::HRectangle(const Point& p, const size_t lenX, const size_t lenY) : _a(p), _lenX(lenX), _lenY(lenY) {}

HRectangle::HRectangle(const HRectangle& hr) : _a(hr._a), _lenX(hr._lenX), _lenY(hr._lenY) {}

HRectangle& HRectangle::operator=(const HRectangle& hr) {

	_a = hr._a;
	_lenX = hr._lenX;
	_lenY = hr._lenY;

	return *this;
}

const Point HRectangle::apexB() const {
	return Point(_a.x(), _a.y() + _lenY);
}
const Point HRectangle::apexC() const {
	return Point(_a.x() + _lenX, _a.y() + _lenY);
}
const Point HRectangle::apexD() const {
	return Point(_a.x() + _lenX, _a.y());
}

const Segment HRectangle::side_AB() const {
	return Segment(apexA(), apexB());
}
const Segment HRectangle::side_BC() const {
	return Segment(apexB(), apexC());
}
const Segment HRectangle::side_CD() const {
	return Segment(apexC(), apexD());
}
const Segment HRectangle::side_DA() const {
	return Segment(apexD(), apexA());
}


void HRectangle::setA(const Point& a) {
	_a = a;
}
void HRectangle::setB(const Point& b) {
	_a.x() = b.x();
	_a.y() = b.y()-_lenY;
}
void HRectangle::setC(const Point& c) {
	_a.x() = c.x() - _lenX;
	_a.y() = c.y() - _lenY;
}
void HRectangle::setD(const Point& d) {
	_a.x() = d.x() - _lenX;
	_a.y() = d.y();
}

HRectangle operator+(const HTetragon& a, const HTetragon& b)
{
	size_t leftX = min(a.apexA().x(), b.apexA().x());
	size_t bottomY = min(a.apexA().y(), b.apexA().y());

	size_t rightX = max(a.apexA().x(), b.apexA().x());
	size_t topY = max(a.apexA().y(), b.apexA().y());

#ifndef NDEBUG
	HRectangle res (Point(leftX, bottomY), rightX - leftX, topY - bottomY);
	assert(a<res && b<res);
	return res;
#else
	return HRectangle(Point(leftX, bottomY), rightX - leftX, topY - bottomY);
#endif // !NDEBUG

}