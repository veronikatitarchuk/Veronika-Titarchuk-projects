#pragma once
#include "Point.h"
#include "Segment.h"

class HTetragon
{
public:
	HTetragon();
	virtual ~HTetragon() = 0;

	virtual double perimeter() const = 0;
	virtual double area() const = 0;

	virtual const Point apexA() const = 0;
	virtual const Point apexB() const = 0;
	virtual const Point apexC() const = 0;
	virtual const Point apexD() const = 0;

	virtual const Segment side_AB() const = 0;
	virtual const Segment side_BC() const = 0;
	virtual const Segment side_CD() const = 0;
	virtual const Segment side_DA() const = 0;
};

std::ostream& operator<<(std::ostream& os, const HTetragon& t);

bool operator<(const HTetragon&, const HTetragon&);

