#include "HSquare.h"

HSquare::HSquare():HRectangle(Point(0, 0), 1, 1) {}

HSquare::HSquare(const Point& p, const size_t len):HRectangle(p, len, len) {}

HSquare::HSquare(const HSquare& hs) : HRectangle(dynamic_cast<const HRectangle&>(hs)) {}

HSquare& HSquare::operator=(const HSquare& hs) {
	HRectangle::operator=(hs);
	return *this;
}