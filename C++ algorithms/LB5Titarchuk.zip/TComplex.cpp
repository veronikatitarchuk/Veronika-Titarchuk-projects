#include "Complex.h"

TComplex::TComplex(const double ro, const double phi) :
	_ro(ro), _phi(phi)
{
#ifndef NDEBUG    
	cout << "TComplex was created: " << *this << endl;
#endif
}

TComplex::TComplex(const TComplex& z) :
	_ro(z.mod()), _phi(z.arg())
{
#ifndef NDEBUG    
	cout << "TComplex was copied: " << *this << endl;
#endif
}
TComplex::~TComplex()
{
#ifndef NDEBUG    
	cout << "TComplex was deleted: " << *this << endl;
#endif
}

TComplex::operator AComplex() const {
#ifndef NDEBUG    
	cout << "Form changed from T to A: " << *this << endl;
#endif
	return AComplex(re(), im());

}

const TComplex operator*(const TComplex& a, const TComplex& b) {
	return TComplex(a.mod() * b.mod(), a.arg() + b.arg());
}

const TComplex operator/(const TComplex& a, const TComplex& b) {
	return TComplex(a.mod() / b.mod(), a.arg() - b.arg());
}

ostream& operator<<(ostream& os, const TComplex& a) {
	cout << "(ro = " << a.mod() << ", phi = " << a.arg() << ")";
	return os;
}

istream& operator>>(istream& is, TComplex& a) {
	double r;
	double p;
	cout << "Type in ro: ";
	cin >> r;
	cout << "Type in phi: ";
	cin >> p;
	a.mod() = r;
	a.arg() = p;
	return is;
}