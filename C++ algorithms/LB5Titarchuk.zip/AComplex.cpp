#include "Complex.h"

AComplex::AComplex(const double re, const double im) :
	_re(re), _im(im)
{
#ifndef NDEBUG    
	cout << "AComplex was created: " << *this << endl;
#endif
}

AComplex::AComplex(const AComplex& z) :
	_re(z.re()), _im(z.im())
{
#ifndef NDEBUG    
	cout << "AComplex was copied: " << *this << endl;
#endif
}

AComplex::~AComplex()
{
#ifndef NDEBUG    
	cout << "AComplex was deleted: " << *this << endl;
#endif
}

AComplex::operator TComplex() const {
#ifndef NDEBUG    
	cout << "Form changed from A to T: " << *this << endl;
#endif
	return TComplex(mod(), arg());

}


const AComplex operator+(const AComplex& a, const AComplex& b) {
	return AComplex(b.re() + a.re(), b.im() + a.im());
}
// �������� ���������: ����������� ������ 
const AComplex operator-(const AComplex& a, const AComplex& b) {
	return AComplex(a.re() - b.re(), a.im() - b.im());
}

bool operator==(const AComplex& a, const AComplex& b) {
	if (a.re() == b.re() && a.im() == b.im())
		return true;
	else return false;
}

bool operator!=(const AComplex& a, const AComplex& b) {
	return !(a == b);
}

ostream& operator<<(ostream& os, const AComplex& a) {
	cout << "(" << a.re() << ", " << a.im() << "i)";
	return os;
}

istream& operator>>(istream& is, AComplex& a) {
	double r;
	double i;
	cout << "Type in real part: ";
	cin >> r;
	cout << "Type in imaginary part: ";
	cin >> i;
	a.re() = r;
	a.im() = i;
	return is;
}
