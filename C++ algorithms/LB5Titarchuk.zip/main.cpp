
#include "Complex.h"
#include <iostream>
using namespace std;

//Turn on or off NDEBUG in Header.h if needed
int main()
{
	//�������� � ������������� ���
	AComplex z1(2, 7), z2(1, 8);
	cout << "z1-z2: " << z1 - z2 << endl;
	cout << "z1+z2: " << z1 + z2 << endl;
	cout << "z1*z2: " << z1 * z2 << endl;
	cout << "z1*10: " << z1 * 10 << endl;
	cout << "10*z1: " << 10 * z1 << endl;
	cout << "z1/z2: " << z1 / z2 << endl;
	cout << "z1/10: " << z1 / 10 << endl;
	cout << "10/z1: " << 10 / z1 << endl;
	AComplex z3(z1);
	cout << z3 << ": was copied from z1" << endl;
	z3 = z2;
	cout << z3 << endl;
	TComplex t(3, 2);
	//�������� ����������
	cout << "z1+t: " << z1 + t << endl;
	cout << "t+z1: " << t + z1 << endl;
	cout << "z1+t: " << z1 + t << endl;
	cout << "t-z1: " << t - z1 << endl;
	cout << "z1-t: " << z1 - t << endl;
	cout << "z1*t: " << z1 * t << endl;
	cout << "t*z1: " << t * z1 << endl;
	cout << "z1/t: " << z1 / t << endl;
	cout << "t/z1: " << t / z1 << endl;
	TComplex t5(z1);
	cout << t5 << ": was copied from z1" << endl;
	t5 = z2;
	cout << t5 << endl;
	z1 = t;
	cout << z1 << endl;
	AComplex z4(t);
	cout << z4 << ": was copied from t" << endl;
	//�������� � ����������������� ���
	TComplex t2(5, 6), t3(8, 11);
	cout << "t2-t3: " << t2 - t3 << endl;
	cout << "t3+z2: " << t3 + z2 << endl;
	cout << "t3*t2: " << t3 * z2 << endl;
	cout << "t2*10: " << t2 * 10 << endl;
	cout << "10*t2: " << 10 * t2 << endl;
	cout << "t3/t2: " << t3 / t2 << endl;
	cout << "t2/10: " << t2 / 10 << endl;
	cout << "10/t2: " << 10 / t2 << endl;
	TComplex t4(t2);
	cout << t4 << ": was copied from t2" << endl;
	t3 = t2;
	cout << t3 << endl;
	cout << "Testing other" << endl;
	cout << "T form tests" << endl;
	cout << t.re() << endl;
	cout << t.im() << endl;
	cout << t.mod() << endl;
	cout << t.arg() << endl;
	t.mod() = 15;
	t.arg() = 20;
	cout << t << endl;
	AComplex z(10, 50);
	cout << "A form tests" << endl;
	cout << z.re() << endl;
	cout << z.im() << endl;
	cout << z.mod() << endl;
	cout << z.arg() << endl;
	z.re() = 15;
	z.im() = 20;
	cout << z << endl;
	cout << z.conj() << endl;
	//Mixed types
	cout << (z == t) << endl;
	cout << (z != t) << endl;


	AComplex z6(15, 20);
	cout << (z == z6) << endl;
	cout << (z != z6) << endl;
	cout << t2 << endl;
	cout << t3 << endl;
	cout << (t2 == t3) << endl;
	cout << (t2 != t3) << endl;
	cout << AComplex(t3) << endl;
	cout << AComplex(t3).conj() << endl;
}
