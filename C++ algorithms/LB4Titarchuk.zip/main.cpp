#include "triangle.h"

using namespace std;

int main() 
{
	Triangle tr1 = Triangle();
	cout << tr1 << endl;

	Triangle tr2 = Triangle(3, 5, 1, 2, 8, 6);
	cout << tr2 << endl;

	Point p1 = Point(2, 3);
	Point p2 = Point(10, 20);
	Point p3 = Point(-3, -7);
	Triangle tr3 = Triangle(p1, p2, p3);
	cout << tr3 << endl;

	Triangle tr4 = Triangle(tr2);
	cout << tr4 << endl;

	tr4.~Triangle();

	//median from point a of tr3
	Segment md1 = tr3.median(tr3.a());
	cout << "Segment median: " << md1 << endl;
	cout << "Median length: " << md1.length() << " sm." << endl;

	//sides
	cout << "Side ab of triangle 3: " << tr3.ab().length() << " sm." << endl;
	cout << "Side bc of triangle 2: " << tr2.bc().length() << " sm." << endl;


	return 0;
}