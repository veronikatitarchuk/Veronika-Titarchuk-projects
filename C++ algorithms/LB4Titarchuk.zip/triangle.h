#include "segment.h"
#include <iostream>

#ifndef _TRIANGLE_H_
#define _TRIANGLE_H_

class Triangle 
{
private:
	static int _freeID;
	const int _myId;
	Point _a;
	Point _b;
	Point _c;
	Segment _ab;
	Segment _bc;
	Segment _ac;

public:
	//constructors
	Triangle(const double x1 = 0, const double y1 = 0, const double x2 = 0, const double y2 = 1, const double x3 = 1, const double y3 = 0);
	Triangle(Point a, Point b, Point c);

	//copy
	Triangle(const Triangle&);

	//destructor
	~Triangle();

	Triangle& operator=(const Triangle&);

	//selectors of the segments
	const Segment& ab() const { return _ab; }
	const Segment& ac() const { return _ac; }
	const Segment& bc() const { return _bc; }

	//selector-modifier of the segments
	Segment& ab() { return _ab; }
	Segment& ac() { return _ac; }
	Segment& bc() { return _bc; }

	//selectors of the points
	const Point& a() const { return _a; }
	const Point& b() const { return _b; }
	const Point& c() const { return _c; }

	//selector-modifiers of the points
	Point& a() { return _a; }
	Point& b() { return _b; }
	Point& c() { return _c; }

	const int getID() const { return _myId; }

	static int amount() { return _freeID; }

	Segment median(Point);
};

ostream& operator<<(ostream&, const Triangle&);


#endif // !_TRIANGLE_H_