#include "triangle.h"

int Triangle::_freeID = 0;

Triangle::Triangle(const double x1, const double y1, const double x2, const double y2, const double x3, const double y3) 
	:_a(x1, y1), _b(x2, y2), _c(x3, y3), _ab(_a, _b), _bc(_b, _c), _ac(_a, _c), _myId(++_freeID)
{
#ifndef NDEBUG
	cout << "Triangle " << _myId << " created." << endl;
#endif // !NDEBUG
	return;
}

Triangle::Triangle(Point a, Point b, Point c): _a(a), _b(b), _c(c), _ab(_a, _b), _bc(_b, _c), _ac(_a, _c), _myId(++_freeID)
{
#ifndef NDEBUG
	cout << "Triangle " << _myId << " created." << endl;
#endif // !NDEBUG
	return;
}

Triangle::Triangle(const Triangle& tr) : _a(tr._a), _b(tr._b), _c(tr._c), 
	_ab(tr._a, tr._b), _bc(tr._b, tr._c), _ac(tr._a, tr._c), _myId(++_freeID)
{
#ifndef NDEBUG
	cout << "Triangle " << _myId << " coppied." << endl;
#endif // !NDEBUG
	return;
}

Triangle::~Triangle()
{
#ifndef NDEBUG
	cout << "Triangle removed." << endl;
#endif // !1

	return;
}

Triangle& Triangle:: operator=(const Triangle& tr)
{
	_a = tr._a;
	_b = tr._b;
	_c = tr._c;
	_ab = tr._ab;
	_ac = tr._ac;
	_bc = tr._bc;

	return *this;
}

ostream& operator<<(ostream& ostr, const Triangle& tr)
{
	ostr << '[' << tr.a() << ';' << tr.b() << ';' << tr.c() << ']';
	return ostr;
}

Segment Triangle::median(Point p)
{
	if (p == _a) 
	{
		Point mp((_b.x() + _c.x()) / 2, (_b.y() + _c.y()) / 2);
		return Segment(_a, mp);
	}

	if (p == _b)
	{
		Point mp((_a.x() + _c.x()) / 2, (_a.y() + _c.y()) / 2);
		return Segment(_b, mp);
	}

	Point mp((_b.x() + _a.x()) / 2, (_b.y() + _a.y()) / 2);
	return Segment(_c, mp);
}